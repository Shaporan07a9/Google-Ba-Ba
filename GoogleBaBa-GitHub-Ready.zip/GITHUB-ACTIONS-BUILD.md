# Build APK with GitHub Actions

1. Create a new GitHub repository.
2. Extract this ZIP and upload the *contents* of the extracted folder to the repository root (do not create an extra `googlebaba/` folder).
3. Commit and push to `main` (or `master`).
4. Open the repository's **Actions** tab.
5. Select **Build Google Ba Ba APK** and wait for the workflow to finish.
6. Open the successful workflow run, scroll to **Artifacts**, and download `GoogleBaBa-debug-apk`.
7. Extract the downloaded artifact. Install the APK on an Android device.

You can also run the workflow manually using **Actions → Build Google Ba Ba APK → Run workflow**.

The workflow builds a debug APK. It does not create a signed Play Store release APK.
