package com.google.baba.visualizer;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PointF;
import android.util.AttributeSet;
import androidx.annotation.NonNull;
import com.google.baba.visualizer.entity.PlayerEntity;
import java.util.List;
import java.util.Locale;

/**
 * Custom View that renders ESP-style visualization of player entities.
 * Draws bounding boxes, names, distance, health bars, skeletons, and direction indicators.
 */
public class VisualizerView extends View {

    // Paint objects for different visualization elements
    private final Paint boxPaint;
    private final Paint textPaint;
    private final Paint healthBarBgPaint;
    private final Paint healthBarFgPaint;
    private final Paint skeletonPaint;

    // Cached drawing state
    private List<PlayerEntity> currentEntities;
    private boolean showBox;
    private boolean showName;
    private boolean showDistance;
    private boolean showHealth;
    private boolean showSkeleton;
    private boolean showDirection;
    private boolean showStatus;

    // Screen dimensions and scaling
    private float screenWidth;
    private float screenHeight;
    private float centerX;
    private float centerY;
    private float scale;

    public VisualizerView(Context context) {
        super(context);
        initPaintObjects();
    }

    public VisualizerView(Context context, AttributeSet attrs) {
        super(context, attrs);
        initPaintObjects();
    }

    public VisualizerView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        initPaintObjects();
    }

    private void initPaintObjects() {
        // Paint for bounding boxes - color will be set per entity
        boxPaint = new Paint();
        boxPaint.setStyle(Paint.Style.STROKE);
        boxPaint.setStrokeWidth(3f);
        boxPaint.setAntiAlias(true);

        // Paint for text
        textPaint = new Paint();
        textPaint.setColor(Color.WHITE);
        textPaint.setAntiAlias(true);
        textPaint.setTextSize(14f);
        textPaint.setStrokeWidth(0f);

        // Paint for health bar background
        healthBarBgPaint = new Paint();
        healthBarBgPaint.setColor(Color.parseColor("#333333"));
        healthBarBgPaint.setStyle(Paint.Style.FILL);
        healthBarBgPaint.setAntiAlias(true);

        // Paint for health bar foreground
        healthBarFgPaint = new Paint();
        healthBarFgPaint.setAntiAlias(true);

        // Paint for skeleton lines
        skeletonPaint = new Paint();
        skeletonPaint.setColor(Color.parseColor("#00ff88"));
        skeletonPaint.setStyle(Paint.Style.STROKE);
        skeletonPaint.setStrokeWidth(2f);
        skeletonPaint.setAntiAlias(true);
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        screenWidth = w;
        screenHeight = h;
        centerX = w / 2f;
        centerY = h / 2f;
        // Scale: entities within 500 units world space are visible
        scale = Math.min(w, h) / 500f;
    }

    /**
     * Sets the entities and visualization options to render.
     * This stores the state; onDraw() will use it to render.
     *
     * @param entities    List of player entities to render
     * @param showBox     Whether to show player bounding boxes
     * @param showName    Whether to show player names
     * @param showDistance Whether to show distance labels
     * @param showHealth   Whether to show health bars
     * @param showSkeleton Whether to show skeleton visualization
     * @param showDirection Whether to show direction indicators
     * @param showStatus   Whether to show status labels
     */
    public void setEntitiesAndOptions(
            List<PlayerEntity> entities,
            boolean showBox,
            boolean showName,
            boolean showDistance,
            boolean showHealth,
            boolean showSkeleton,
            boolean showDirection,
            boolean showStatus) {

        this.currentEntities = entities;
        this.showBox = showBox;
        this.showName = showName;
        this.showDistance = showDistance;
        this.showHealth = showHealth;
        this.showSkeleton = showSkeleton;
        this.showDirection = showDirection;
        this.showStatus = showStatus;
        // Trigger redraw
        invalidate();
    }

    /**
     * Gets the current visible player count based on ignore bots filter.
     */
    public int getVisiblePlayerCount() {
        if (currentEntities == null) return 0;

        int count = 0;
        for (PlayerEntity entity : currentEntities) {
            // When ignore bots is active, only show non-bot entities
            // The filter is applied at the ViewModel level, but we check here too
            if (!entity.isBot()) {
                count++;
            }
        }
        return count;
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        if (currentEntities == null) {
            postInvalidateOnAnimation();
            return;
        }

        // Clear screen with background color
        canvas.drawColor(Color.BLACK);

        // Draw each entity with all enabled visualization options
        for (PlayerEntity entity : currentEntities) {
            drawEntity(canvas, entity);
        }

        // Post invalidate for continuous animation
        postInvalidateOnAnimation();
    }

    private void drawEntity(Canvas canvas, PlayerEntity entity) {
        // Convert world position to screen coordinates
        float[] position = entity.getPosition();
        if (position == null) return;

        float screenX = centerX + (position[0] * scale);
        float screenY = centerY - (position[1] * scale); // Invert Y axis

        // Entity radius for box sizing (scaled)
        float entityRadius = 20f * scale;

        // Determine box color based on entity type
        if (entity.isBot()) {
            boxPaint.setColor(Color.parseColor("#ff0047")); // Red for bots
        } else {
            boxPaint.setColor(Color.parseColor("#00d2ff")); // Blue for humans
        }
        boxPaint.setStrokeWidth(3f);

        // 1. Draw bounding box
        if (showBox) {
            drawBoundingBox(canvas, screenX, screenY, entityRadius);
        }

        // 2. Draw player name
        if (showName && entity.getName() != null) {
            drawPlayerName(canvas, screenX, screenY, entity.getName());
        }

        // 3. Draw distance label
        if (showDistance) {
            drawDistanceLabel(canvas, screenX, screenY, entity.getDistance());
        }

        // 4. Draw health bar
        if (showHealth) {
            drawHealthBar(canvas, screenX, screenY, entity.getHealth());
        }

        // 5. Draw skeleton
        if (showSkeleton) {
            drawSkeleton(canvas, entity.getSkeletonPoints());
        }

        // 6. Draw direction indicator
        if (showDirection) {
            drawDirectionIndicator(canvas, screenX, screenY, entity.getDirection());
        }

        // 7. Draw status label
        if (showStatus) {
            drawStatusLabel(canvas, screenX, screenY, entity.getStatus());
        }
    }

    private void drawBoundingBox(Canvas canvas, float screenX, float screenY, float radius) {
        float boxSize = radius * 2.5f;
        float left = screenX - boxSize / 2f;
        float top = screenY - boxSize / 2f;
        float right = screenX + boxSize / 2f;
        float bottom = screenY + boxSize / 2f;

        // Draw rectangular box
        canvas.drawRect(left, top, right, bottom, boxPaint);
    }

    private void drawPlayerName(Canvas canvas, float screenX, float screenY, String name) {
        textPaint.setColor(Color.WHITE);
        float labelY = screenY - 30f;
        canvas.drawText(name, screenX - textPaint.measureText(name) / 2f, labelY, textPaint);
    }

    private void drawDistanceLabel(Canvas canvas, float screenX, float screenY, float distance) {
        textPaint.setColor(Color.parseColor("#66ffff"));
        String distanceText = String.format(Locale.getDefault(), "%.1f m", distance / 10f);
        float labelY = screenY + 15f;
        canvas.drawText(distanceText, screenX - textPaint.measureText(distanceText) / 2f, labelY, textPaint);
    }

    private void drawHealthBar(Canvas canvas, float screenX, float screenY, int health) {
        float barWidth = 40f * scale;
        float barHeight = 6f * scale;
        float barX = screenX - barWidth / 2f;
        float barY = screenY + 30f;

        // Draw background bar
        healthBarBgPaint.setColor(Color.parseColor("#333333"));
        canvas.drawRect(barX, barY, barX + barWidth, barY + barHeight, healthBarBgPaint);

        // Draw health foreground (portion proportional to health)
        float healthWidth = (health / 100f) * barWidth;
        // Green for high health, red for low health
        if (health > 50) {
            healthBarFgPaint.setColor(Color.GREEN);
        } else if (health > 20) {
            healthBarFgPaint.setColor(Color.YELLOW);
        } else {
            healthBarFgPaint.setColor(Color.RED);
        }
        canvas.drawRect(barX, barY, barX + healthWidth, barY + barHeight, healthBarFgPaint);
    }

    private void drawSkeleton(Canvas canvas, List<float[]> skeletonPoints) {
        if (skeletonPoints == null || skeletonPoints.size() < 2) return;

        skeletonPaint.setStrokeWidth(2f * scale);

        for (int i = 0; i < skeletonPoints.size() - 1; i++) {
            float[] start = skeletonPoints.get(i);
            float[] end = skeletonPoints.get(i + 1);

            float startX = centerX + (start[0] * scale);
            float startY = centerY - (start[1] * scale);
            float endX = centerX + (end[0] * scale);
            float endY = centerY - (end[1] * scale);

            canvas.drawLine(startX, startY, endX, endY, skeletonPaint);
        }
    }

    private void drawDirectionIndicator(Canvas canvas, float screenX, float screenY, String direction) {
        textPaint.setColor(Color.parseColor("#00d2ff"));
        String arrow = " ▲";
        float labelY = screenY - 50f;
        canvas.drawText(direction + arrow, screenX - textPaint.measureText(direction + arrow) / 2f, labelY, textPaint);
    }

    private void drawStatusLabel(Canvas canvas, float screenX, float screenY, String status) {
        textPaint.setColor(Color.parseColor("#00ff88"));
        float labelY = screenY + 50f;
        canvas.drawText(status, screenX - textPaint.measureText(status) / 2f, labelY, textPaint);
    }
}