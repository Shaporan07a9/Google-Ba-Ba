package com.google.baba.visualizer;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

/**
 * About screen displaying information about Google Ba Ba application.
 */
public class AboutActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.about_screen);
    }
}