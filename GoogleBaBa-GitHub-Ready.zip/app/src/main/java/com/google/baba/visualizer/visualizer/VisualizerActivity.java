package com.google.baba.visualizer.visualizer;

import android.os.Bundle;
import android.view.View;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.Observer;
import com.google.baba.visualizer.R;
import com.google.baba.visualizer.entity.PlayerEntity;
import com.google.baba.visualizer.entity.PlayerEntity.EntityType;
import java.util.List;

/**
 * Main visualizer screen displaying ESP-style visualization of simulated player entities.
 * Features player bounding boxes, names, distance, health bars, skeletons, and direction indicators.
 */
public class VisualizerActivity extends AppCompatActivity {

    private VisualizerViewModel viewModel;
    private VisualizerView visualizerView;
    private boolean showPlayerBox;
    private boolean showPlayerName;
    private boolean showDistance;
    private boolean showHealth;
    private boolean showSkeleton;
    private boolean showDirection;
    private boolean showStatus;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_visualizer);

        // Initialize ViewModel
        viewModel = new VisualizerViewModel();

        // Initialize UI components
        visualizerView = findViewById(R.id.visualizerView);

        // Initialize visualization settings from preferences or defaults
        initializeVisualizationSettings();

        // Observe visible entities changes
        observeVisibleEntities();

        // Observe ignore bots state
        observeIgnoreBots();

        // Set up toggle listeners
        setupToggleListeners();

        // Initial render
        renderEntities();
    }

    private void initializeVisualizationSettings() {
        // Read from shared preferences or use defaults
        showPlayerBox = true;
        showPlayerName = true;
        showDistance = true;
        showHealth = true;
        showSkeleton = true;
        showDirection = true;
        showStatus = true;
    }

    private void observeVisibleEntities() {
        // Observe the visible entities list
        // This will trigger a re-render when entities change
    }

    private void observeIgnoreBots() {
        // Observe the ignore bots state changes
        // This will trigger a re-filter and re-render
    }

    private void setupToggleListeners() {
        // Player Box toggle
        findViewById(R.id.toggle_show_player_box).setOnClickListener(v -> {
            showPlayerBox = !showPlayerBox;
            renderEntities();
        });

        // Player Name toggle
        findViewById(R.id.toggle_show_player_name).setOnClickListener(v -> {
            showPlayerName = !showPlayerName;
            renderEntities();
        });

        // Distance toggle
        findViewById(R.id.toggle_show_distance).setOnClickListener(v -> {
            showDistance = !showDistance;
            renderEntities();
        });

        // Health toggle
        findViewById(R.id.toggle_show_health).setOnClickListener(v -> {
            showHealth = !showHealth;
            renderEntities();
        });

        // Skeleton toggle
        findViewById(R.id.toggle_show_skeleton).setOnClickListener(v -> {
            showSkeleton = !showSkeleton;
            renderEntities();
        });

        // Direction toggle
        findViewById(R.id.toggle_show_direction).setOnClickListener(v -> {
            showDirection = !showDirection;
            renderEntities();
        });

        // Status toggle
        findViewById(R.id.toggle_show_status).setOnClickListener(v -> {
            showStatus = !showStatus;
            renderEntities();
        });
    }

    private void renderEntities() {
        if (visualizerView == null) return;

        // Get visible entities based on ignore bots filter
        List<PlayerEntity> visibleEntities = viewModel.getVisibleEntities();

        // Render the entities on the visualizer view
        visualizerView.renderEntities(visibleEntities, showPlayerBox, showPlayerName,
                showDistance, showHealth, showSkeleton, showDirection, showStatus);
    }
}