package com.google.baba.visualizer;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import android.view.View;

public class GradientBackground extends View {

    private final Drawable gradientTop;
    private final Drawable gradientBottom;
    private final int screenWidth;
    private final int screenHeight;

    public GradientBackground(Context context, AttributeSet attrs) {
        super(context, attrs);
        this.screenWidth = context.getResources().getDisplayMetrics().widthPixels;
        this.screenHeight = context.getResources().getDisplayMetrics().heightPixels;

        // Top gradient (dark to slightly lighter)
        gradientTop = ContextCompat.getDrawable(context, R.drawable.gradient_top);
        gradientTop.setBounds(0, 0, screenWidth, screenHeight / 2);

        // Bottom gradient (darker)
        gradientBottom = ContextCompat.getDrawable(context, R.drawable.gradient_bottom);
        gradientBottom.setBounds(0, screenHeight / 2, screenWidth, screenHeight);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        gradientTop.draw(canvas);
        gradientBottom.draw(canvas);
        // Redraw on layout change
        postInvalidateOnAnimation();
    }
}