package com.google.baba.visualizer;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.CompoundButton;
import androidx.appcompat.widget.SwitchCompat;

/**
 * Custom Switch widget for the Google Ba Ba application.
 * Provides a neon-styled toggle switch for visualization features.
 */
public class ToggleSwitch extends SwitchCompat {

    public ToggleSwitch(Context context) {
        super(context);
        init();
    }

    public ToggleSwitch(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public ToggleSwitch(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    private void init() {
        // Set text colors and appearance
        setTextColor(getResources().getColor(android.R.color.white));
        setSwitchTextAppearance(context, android.R.attr.alertDialogSwitchMaterialStyle);
    }
}