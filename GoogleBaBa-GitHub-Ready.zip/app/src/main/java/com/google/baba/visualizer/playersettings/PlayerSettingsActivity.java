package com.google.baba.visualizer.playersettings;

import android.os.Bundle;
import android.view.View;
import androidx.appcompat.app.AppCompatActivity;
import com.google.baba.visualizer.R;
import com.google.baba.visualizer.visualizer.VisualizerView;
import com.google.baba.visualizer.visualizer.VisualizerViewModel;

/**
 * Player Settings screen with independent toggles for each visualization feature.
 * Each option has its own ON/OFF toggle for controlling what information
 * is displayed for player entities.
 */
public class PlayerSettingsActivity extends AppCompatActivity {

    private VisualizerView visualizerView;
    private VisualizerViewModel viewModel;

    // UI toggle references
    private android.widget.Switch swShowPlayerBox;
    private android.widget.Switch swShowPlayerName;
    private android.widget.Switch swShowDistance;
    private android.widget.Switch swShowHealth;
    private android.widget.Switch swShowSkeleton;
    private android.widget.Switch swShowDirection;
    private android.widget.Switch swShowStatus;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_player_settings);

        // Initialize ViewModel and UI components
        viewModel = new VisualizerViewModel();
        visualizerView = findViewById(R.id.visualizerView);

        // Initialize UI toggles
        initializeToggles();

        // Initial render with current settings
        renderSettings();
    }

    private void initializeToggles() {
        swShowPlayerBox = findViewById(R.id.sw_show_player_box);
        swShowPlayerName = findViewById(R.id.sw_show_player_name);
        swShowDistance = findViewById(R.id.sw_show_distance);
        swShowHealth = findViewById(R.id.sw_show_health);
        swShowSkeleton = findViewById(R.id.sw_show_skeleton);
        swShowDirection = findViewById(R.id.sw_show_direction);
        swShowStatus = findViewById(R.id.sw_show_status);

        // Set up toggle change listeners
        swShowPlayerBox.setOnCheckedChangeListener((buttonView, isChecked) -> {
            viewModel.setShowPlayerBox(isChecked);
            visualizerView.invalidate();
        });

        swShowPlayerName.setOnCheckedChangeListener((buttonView, isChecked) -> {
            viewModel.setShowPlayerName(isChecked);
            visualizerView.invalidate();
        });

        swShowDistance.setOnCheckedChangeListener((buttonView, isChecked) -> {
            viewModel.setShowDistance(isChecked);
            visualizerView.invalidate();
        });

        swShowHealth.setOnCheckedChangeListener((buttonView, isChecked) -> {
            viewModel.setShowHealth(isChecked);
            visualizerView.invalidate();
        });

        swShowSkeleton.setOnCheckedChangeListener((buttonView, isChecked) -> {
            viewModel.setShowSkeleton(isChecked);
            visualizerView.invalidate();
        });

        swShowDirection.setOnCheckedChangeListener((buttonView, isChecked) -> {
            viewModel.setShowDirection(isChecked);
            visualizerView.invalidate();
        });

        swShowStatus.setOnCheckedChangeListener((buttonView, isChecked) -> {
            viewModel.setShowStatus(isChecked);
            visualizerView.invalidate();
        });
    }

    private void renderSettings() {
        // Set toggle states from ViewModel
        swShowPlayerBox.setChecked(viewModel.isShowPlayerBox());
        swShowPlayerName.setChecked(viewModel.isShowPlayerName());
        swShowDistance.setChecked(viewModel.isShowDistance());
        swShowHealth.setChecked(viewModel.isShowHealth());
        swShowSkeleton.setChecked(viewModel.isShowSkeleton());
        swShowDirection.setChecked(viewModel.isShowDirection());
        swShowStatus.setChecked(viewModel.isShowStatus());

        // Render entities with current settings
        boolean ignoreBots = viewModel.isIgnoreBots();
        List<PlayerEntity> visibleEntities = viewModel.getVisibleEntities();

        visualizerView.setEntitiesAndOptions(
                visibleEntities,
                viewModel.isShowPlayerBox(),
                viewModel.isShowPlayerName(),
                viewModel.isShowDistance(),
                viewModel.isShowHealth(),
                viewModel.isShowSkeleton(),
                viewModel.isShowDirection(),
                viewModel.isShowStatus()
        );

        // Update ignore bots toggle text
        android.widget.Switch ignoreBotsSwitch = findViewById(R.id.sw_ignore_bots_player);
        if (ignoreBotsSwitch != null) {
            ignoreBotsSwitch.setChecked(ignoreBots);
            ignoreBotsSwitch.setText(ignoreBots ? R.string.ignore_bots_on : R.string.ignore_bots_off);
        }
    }
}